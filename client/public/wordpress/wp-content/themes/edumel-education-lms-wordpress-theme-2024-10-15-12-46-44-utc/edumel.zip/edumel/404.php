<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package has-submenu
 */

get_header();

edumel_404_content();

get_footer();
